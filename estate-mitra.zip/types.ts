
export interface Property {
  id: string;
  name: string;
  type: 'Villa' | 'Plot' | 'Apartment';
  area: number;
  areaUnit: 'sq_yards' | 'sq_ft';
}

export interface Project {
  id: string;
  name: string;
  location: string;
  description: string;
  longDescription: string;
  featured: boolean;
  heroImage: string;
  images: string[];
  properties: Property[];
  isNegotiable: boolean;
  priceRange: string;
}

export interface Lead {
  name: string;
  phone: string;
  projectId: string;
}

export interface ChatMessage {
    sender: 'user' | 'bot';
    text: string;
    isLoading?: boolean;
}
