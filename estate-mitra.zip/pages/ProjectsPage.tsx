
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getProjects } from '../services/api';
import type { Project } from '../types';
import { Card, Spinner } from '../components/shared';
import { MapPin } from 'lucide-react';

const ProjectCard: React.FC<{ project: Project }> = ({ project }) => {
    const navigate = useNavigate();
    return (
        <Card onClick={() => navigate(`/projects/${project.id}`)} className="flex flex-col">
            <div className="relative">
                <img src={project.heroImage} alt={project.name} className="w-full h-56 object-cover" />
                 {project.featured && <div className="absolute top-2 right-2 bg-indigo-500 text-white px-2 py-1 text-xs font-bold rounded">FEATURED</div>}
            </div>
            <div className="p-6 flex-grow flex flex-col">
                <h3 className="font-bold text-xl text-gray-800 dark:text-white">{project.name}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center mt-1">
                    <MapPin size={14} className="mr-2" />
                    {project.location}
                </p>
                <p className="text-base text-gray-600 dark:text-gray-300 mt-3 flex-grow">{project.description}</p>
                 <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700 text-right">
                    <span className="text-indigo-600 dark:text-indigo-400 text-lg font-semibold">{project.priceRange}</span>
                </div>
            </div>
        </Card>
    );
};

const ProjectsPage = () => {
    const [projects, setProjects] = useState<Project[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchProjects = async () => {
            try {
                const data = await getProjects();
                setProjects(data);
            } catch (error) {
                console.error("Failed to fetch projects:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchProjects();
    }, []);

    return (
        <div className="bg-gray-50 dark:bg-gray-900 py-12 sm:py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 dark:text-white sm:text-5xl">Our Projects</h1>
                    <p className="mt-4 text-xl text-gray-600 dark:text-gray-300">Find the perfect property that fits your dreams and budget.</p>
                </div>

                {loading ? (
                    <Spinner />
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {projects.map(project => (
                            <ProjectCard key={project.id} project={project} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default ProjectsPage;
