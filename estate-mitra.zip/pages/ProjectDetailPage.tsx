
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getProjectById, submitLead } from '../services/api';
import type { Project, Property, Lead } from '../types';
import { Spinner, Button, Input, Card } from '../components/shared';
import { MapPin, Maximize, CheckCircle, AlertCircle, Home, Layers, Building } from 'lucide-react';
import VirtualAssistant from '../components/VirtualAssistant';


const ContactForm: React.FC<{ projectId: string }> = ({ projectId }) => {
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
    const [message, setMessage] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!name || !phone) {
            setStatus('error');
            setMessage('Please fill in both name and phone number.');
            return;
        }
        setStatus('loading');
        setMessage('');

        const lead: Lead = { name, phone, projectId };
        try {
            const response = await submitLead(lead);
            if(response.success) {
                setStatus('success');
                setMessage('Thank you! Our team will contact you shortly.');
                setName('');
                setPhone('');
            } else {
                setStatus('error');
                setMessage('Something went wrong. Please try again later.');
            }
        } catch (error) {
            setStatus('error');
            setMessage('An unexpected error occurred. Please try again.');
        }
    };

    return (
        <Card className="p-6">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Interested? Get in Touch!</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
                <Input type="text" placeholder="Full Name" value={name} onChange={e => setName(e.target.value)} required disabled={status === 'loading'}/>
                <Input type="tel" placeholder="Phone Number" value={phone} onChange={e => setPhone(e.target.value)} required disabled={status === 'loading'}/>
                <Button type="submit" variant="primary" className="w-full" disabled={status === 'loading'}>
                    {status === 'loading' ? 'Submitting...' : 'Request a Callback'}
                </Button>
            </form>
            {status === 'success' && (
                 <div className="mt-4 flex items-center text-green-600 dark:text-green-400">
                    <CheckCircle className="mr-2" size={20}/>
                    <p>{message}</p>
                </div>
            )}
            {status === 'error' && (
                 <div className="mt-4 flex items-center text-red-600 dark:text-red-400">
                    <AlertCircle className="mr-2" size={20}/>
                    <p>{message}</p>
                </div>
            )}
        </Card>
    );
};


const PropertyIcon = ({ type }: { type: Property['type'] }) => {
    switch (type) {
        case 'Villa': return <Home className="mr-3 text-indigo-500" />;
        case 'Plot': return <Layers className="mr-3 text-indigo-500" />;
        case 'Apartment': return <Building className="mr-3 text-indigo-500" />;
        default: return null;
    }
}

const ProjectDetailPage = () => {
    const { projectId } = useParams<{ projectId: string }>();
    const navigate = useNavigate();
    const [project, setProject] = useState<Project | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!projectId) {
            navigate('/projects');
            return;
        }

        const fetchProject = async () => {
            try {
                const data = await getProjectById(projectId);
                if (data) {
                    setProject(data);
                } else {
                    // Handle not found
                    navigate('/404');
                }
            } catch (error) {
                console.error("Failed to fetch project:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchProject();
    }, [projectId, navigate]);

    if (loading) {
        return <div className="flex justify-center items-center h-screen"><Spinner /></div>;
    }

    if (!project) {
        return <div className="text-center py-20">Project not found.</div>;
    }

    return (
        <div className="bg-white dark:bg-gray-800">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 dark:text-white">{project.name}</h1>
                    <p className="mt-2 text-xl text-gray-600 dark:text-gray-400 flex items-center">
                        <MapPin size={20} className="mr-2"/>
                        {project.location}
                    </p>
                </div>

                {/* Image Gallery */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
                    <div className="col-span-1 md:col-span-2">
                        <img src={project.heroImage} alt={`${project.name} main view`} className="w-full h-auto max-h-[60vh] object-cover rounded-lg shadow-lg"/>
                    </div>
                    {project.images.slice(0, 4).map((img, index) => (
                        <div key={index} className="col-span-1 hidden md:block">
                            <img src={img} alt={`${project.name} view ${index + 1}`} className="w-full h-64 object-cover rounded-lg shadow-md"/>
                        </div>
                    ))}
                </div>

                {/* Main Content */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                    <div className="lg:col-span-2">
                        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">About the Project</h2>
                        <p className="text-lg text-gray-600 dark:text-gray-300 whitespace-pre-line">{project.longDescription}</p>
                        
                        <div className="mt-10">
                            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Available Properties</h3>
                            <div className="space-y-4">
                                {project.properties.map(prop => (
                                    <Card key={prop.id} className="p-4 flex items-center">
                                        <PropertyIcon type={prop.type} />
                                        <div>
                                            <p className="font-semibold text-lg text-gray-800 dark:text-gray-100">{prop.name}</p>
                                            <p className="text-gray-500 dark:text-gray-400">{prop.type} - {prop.area} {prop.areaUnit.replace('_', ' ')}</p>
                                        </div>
                                    </Card>
                                ))}
                            </div>
                        </div>

                        <div className="mt-10 bg-gray-100 dark:bg-gray-700 p-6 rounded-lg">
                           <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Pricing Information</h3>
                           <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">{project.priceRange}</p>
                           {project.isNegotiable && (
                            <span className="inline-block bg-green-100 text-green-800 text-sm font-medium mt-2 px-2.5 py-0.5 rounded-full dark:bg-green-900 dark:text-green-300">
                                Price is Negotiable
                            </span>
                           )}
                        </div>
                    </div>
                    
                    <div className="lg:col-span-1">
                        <div className="sticky top-24">
                           <ContactForm projectId={project.id} />
                        </div>
                    </div>
                </div>
            </div>
            {project && <VirtualAssistant project={project} />}
        </div>
    );
};

export default ProjectDetailPage;
