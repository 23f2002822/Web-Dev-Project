
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getFeaturedProjects } from '../services/api';
import type { Project } from '../types';
import { Card, Spinner, Button } from '../components/shared';
import { MapPin, Home } from 'lucide-react';

const ProjectCard: React.FC<{ project: Project }> = ({ project }) => {
    const navigate = useNavigate();
    return (
        <Card onClick={() => navigate(`/projects/${project.id}`)}>
            <div className="relative">
                <img src={project.heroImage} alt={project.name} className="w-full h-48 object-cover" />
                <div className="absolute top-2 right-2 bg-indigo-500 text-white px-2 py-1 text-xs font-bold rounded">FEATURED</div>
            </div>
            <div className="p-4">
                <h3 className="font-bold text-lg text-gray-800 dark:text-white">{project.name}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center mt-1">
                    <MapPin size={14} className="mr-2" />
                    {project.location}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">{project.description}</p>
                 <div className="mt-4 text-right">
                    <span className="text-indigo-600 dark:text-indigo-400 font-semibold">{project.priceRange}</span>
                </div>
            </div>
        </Card>
    );
};

const HomePage = () => {
    const [featured, setFeatured] = useState<Project[]>([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchProjects = async () => {
            try {
                const data = await getFeaturedProjects();
                setFeatured(data);
            } catch (error) {
                console.error("Failed to fetch featured projects:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchProjects();
    }, []);

    return (
        <div>
            {/* Hero Section */}
            <section className="relative h-[60vh] md:h-[80vh] flex items-center justify-center text-white text-center bg-gray-800">
                <div className="absolute inset-0 bg-black opacity-50 z-0"></div>
                <img src="https://picsum.photos/seed/main-hero/1920/1080" alt="Modern architecture" className="absolute inset-0 w-full h-full object-cover z-[-1]" />
                <div className="relative z-10 p-4">
                    <h1 className="text-4xl md:text-6xl font-extrabold leading-tight tracking-tight">
                        Invest in Your Future
                    </h1>
                    <p className="mt-4 text-lg md:text-xl max-w-2xl mx-auto text-gray-200">
                        Discover premium properties and investment opportunities with Estate Mitra in Visakhapatnam.
                    </p>
                    <Button onClick={() => navigate('/projects')} className="mt-8 text-lg" variant="primary">
                        Explore Projects
                    </Button>
                </div>
            </section>

            {/* Why Choose Us Section */}
            <section className="py-16 sm:py-24 bg-white dark:bg-gray-800">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center">
                        <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-4xl">Why Choose Estate Mitra?</h2>
                        <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">Your trusted partner in real estate investment.</p>
                    </div>
                    <div className="mt-12 grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-3">
                        <div className="text-center">
                            <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white mx-auto">
                                <Home/>
                            </div>
                            <h3 className="mt-6 text-lg font-medium text-gray-900 dark:text-white">Premium Properties</h3>
                            <p className="mt-2 text-base text-gray-500 dark:text-gray-400">Handpicked projects in prime locations ensuring high appreciation and quality living.</p>
                        </div>
                        <div className="text-center">
                             <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white mx-auto">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                            </div>
                            <h3 className="mt-6 text-lg font-medium text-gray-900 dark:text-white">Secure Investments</h3>
                            <p className="mt-2 text-base text-gray-500 dark:text-gray-400">All properties are legally vetted, ensuring a safe and transparent transaction process.</p>
                        </div>
                         <div className="text-center">
                             <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white mx-auto">
                               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                            </div>
                            <h3 className="mt-6 text-lg font-medium text-gray-900 dark:text-white">Professional Guidance</h3>
                            <p className="mt-2 text-base text-gray-500 dark:text-gray-400">Our expert team provides end-to-end support, from site visits to final registration.</p>
                        </div>
                    </div>
                </div>
            </section>
            
            {/* Featured Projects Section */}
            <section className="py-16 sm:py-24 bg-gray-50 dark:bg-gray-900">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-12">
                        <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-4xl">Featured Projects</h2>
                        <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">Prime opportunities available right now.</p>
                    </div>
                    {loading ? (
                        <Spinner />
                    ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                            {featured.map(project => (
                                <ProjectCard key={project.id} project={project} />
                            ))}
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
};

export default HomePage;
