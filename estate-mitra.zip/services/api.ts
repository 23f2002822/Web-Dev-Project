
import type { Project, Lead } from '../types';

export const mockProjects: Project[] = [
  {
    id: 'etor-greens',
    name: 'ETOR Greens',
    location: 'Madhurawada, Vizag',
    description: 'Luxury villas nestled in nature with world-class amenities.',
    longDescription: 'ETOR Greens represents the pinnacle of luxury living in Visakhapatnam. Spread across 25 acres of lush landscape, this exclusive gated community offers a serene escape from the city bustle while maintaining close proximity to key IT hubs, educational institutions, and healthcare facilities. Each villa is designed with meticulous attention to detail, blending modern architecture with natural elements.',
    featured: true,
    heroImage: 'https://picsum.photos/seed/etor-hero/1600/900',
    images: [
      'https://picsum.photos/seed/etor-1/1200/800',
      'https://picsum.photos/seed/etor-2/1200/800',
      'https://picsum.photos/seed/etor-3/1200/800',
      'https://picsum.photos/seed/etor-4/1200/800',
    ],
    isNegotiable: true,
    priceRange: "Starting from ₹1.2 Cr",
    properties: [
      { id: 'villa-a', name: 'Executive Villa', type: 'Villa', area: 300, areaUnit: 'sq_yards' },
      { id: 'villa-b', name: 'Premium Villa', type: 'Villa', area: 450, areaUnit: 'sq_yards' },
    ],
  },
  {
    id: 'sunrise-plots',
    name: 'Sunrise Plots',
    location: 'Anandapuram, Vizag',
    description: 'Secure and high-potential investment plots for your dream home.',
    longDescription: 'Located in the rapidly developing corridor of Anandapuram, Sunrise Plots offers a golden opportunity for investors and homebuyers alike. This VUDA-approved layout is strategically positioned to benefit from upcoming infrastructure projects, ensuring significant appreciation in value. Secure your piece of the future in a well-planned community with wide roads, parks, and essential utilities.',
    featured: true,
    heroImage: 'https://picsum.photos/seed/sunrise-hero/1600/900',
    images: [
      'https://picsum.photos/seed/sunrise-1/1200/800',
      'https://picsum.photos/seed/sunrise-2/1200/800',
    ],
    isNegotiable: false,
    priceRange: "₹25,000 per sq. yard",
    properties: [
      { id: 'plot-1', name: 'East Facing Plot', type: 'Plot', area: 200, areaUnit: 'sq_yards' },
      { id: 'plot-2', name: 'North-East Corner', type: 'Plot', area: 267, areaUnit: 'sq_yards' },
      { id: 'plot-3', name: 'West Facing Plot', type: 'Plot', area: 180, areaUnit: 'sq_yards' },
    ],
  },
  {
    id: 'ocean-heights',
    name: 'Ocean Heights',
    location: 'Beach Road, Vizag',
    description: 'Modern apartments with breathtaking sea views.',
    longDescription: 'Wake up to the sound of waves at Ocean Heights, a premium residential tower on the iconic Beach Road. Offering a range of 2 and 3 BHK apartments, each unit is designed to maximize ocean views and natural light. With state-of-the-art facilities including a rooftop pool, gym, and clubhouse, Ocean Heights is not just a home; it\'s a lifestyle statement.',
    featured: false,
    heroImage: 'https://picsum.photos/seed/ocean-hero/1600/900',
    images: [
        'https://picsum.photos/seed/ocean-1/1200/800',
        'https://picsum.photos/seed/ocean-2/1200/800',
        'https://picsum.photos/seed/ocean-3/1200/800',
    ],
    isNegotiable: true,
    priceRange: "Flats from ₹80 Lakhs",
    properties: [
      { id: 'apt-2bhk', name: '2 BHK Sea View', type: 'Apartment', area: 1250, areaUnit: 'sq_ft' },
      { id: 'apt-3bhk', name: '3 BHK Panorama', type: 'Apartment', area: 1800, areaUnit: 'sq_ft' },
    ],
  },
   {
    id: 'green-valley',
    name: 'Green Valley',
    location: 'Boyapalem, Vizag',
    description: 'Affordable plots in a serene and green environment.',
    longDescription: 'Green Valley is a thoughtfully planned residential layout offering affordable plots for those looking to build their home away from the urban chaos, yet connected to the city. Surrounded by hills and greenery, it provides a peaceful living experience with all necessary approvals and basic infrastructure in place.',
    featured: true,
    heroImage: 'https://picsum.photos/seed/valley-hero/1600/900',
    images: [
        'https://picsum.photos/seed/valley-1/1200/800',
        'https://picsum.photos/seed/valley-2/1200/800',
    ],
    isNegotiable: false,
    priceRange: "₹15,000 per sq. yard",
    properties: [
      { id: 'plot-gv1', name: 'Standard Plot', type: 'Plot', area: 167, areaUnit: 'sq_yards' },
      { id: 'plot-gv2', name: 'Corner Plot', type: 'Plot', area: 200, areaUnit: 'sq_yards' },
    ],
  }
];

export const getProjects = async (): Promise<Project[]> => {
  // Simulate network delay
  await new Promise(res => setTimeout(res, 500));
  return mockProjects;
};

export const getProjectById = async (id: string): Promise<Project | undefined> => {
  // Simulate network delay
  await new Promise(res => setTimeout(res, 500));
  return mockProjects.find(p => p.id === id);
};

export const getFeaturedProjects = async (): Promise<Project[]> => {
    // Simulate network delay
  await new Promise(res => setTimeout(res, 500));
  return mockProjects.filter(p => p.featured);
}

/**
 * Simulates submitting lead data to a backend service,
 * like an API route that connects to Google Sheets.
 */
export const submitLead = async (lead: Lead): Promise<{ success: boolean }> => {
  console.log('Submitting lead to backend:', lead);
  // Simulate network delay
  await new Promise(res => setTimeout(res, 1500));

  // In a real application, this would be a fetch() call to a serverless function
  // or API endpoint which would then securely update a Google Sheet or CRM.
  // For example:
  // const response = await fetch('/api/submit-lead', {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify(lead),
  // });
  // if (!response.ok) return { success: false };
  
  // Simulate a successful submission
  return { success: true };
};
