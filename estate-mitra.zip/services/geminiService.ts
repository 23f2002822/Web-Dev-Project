
import { GoogleGenAI, Chat } from "@google/genai";
import type { Project } from '../types';

// IMPORTANT: In a real application, the API key must be set as an environment variable
// on the server and not exposed on the client side. This is for demonstration purposes.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API key not found. Virtual Assistant will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const initChatWithProjectContext = (project: Project): Chat | null => {
  if (!API_KEY) return null;

  const model = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: `You are 'Estate Mitra Virtual Assistant', a helpful AI guide for the '${project.name}' project located in '${project.location}'.
      Here is the information you have about the project:
      - Description: ${project.longDescription}
      - Price Information: ${project.priceRange}. It is ${project.isNegotiable ? 'negotiable' : 'not negotiable'}.
      - Available properties within this project: ${JSON.stringify(project.properties, null, 2)}
      
      Your role is to answer user questions based ONLY on this provided information. Be friendly, professional, and concise.
      DO NOT make up any information, especially about pricing, availability, or amenities not listed.
      If a user asks a question you cannot answer from the provided context, politely state that you do not have that information and suggest they fill out the contact form to speak with a sales representative for more details.
      Keep your answers brief and to the point.
      `,
    },
  });
  return model;
};

export const sendMessageToBot = async (chat: Chat, message: string) => {
    try {
        const response = await chat.sendMessageStream({ message });
        return response;
    } catch (error) {
        console.error("Error sending message to Gemini:", error);
        throw new Error("Failed to get a response from the virtual assistant.");
    }
};
