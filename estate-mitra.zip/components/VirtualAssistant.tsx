
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { MessageSquare, X, Send, User, Bot } from 'lucide-react';
import { initChatWithProjectContext, sendMessageToBot } from '../services/geminiService';
import type { Project, ChatMessage } from '../types';
import type { Chat, GenerateContentResponse } from '@google/genai';

const VirtualAssistant: React.FC<{ project: Project }> = ({ project }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [chatSession, setChatSession] = useState<Chat | null>(null);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (isOpen) {
            const session = initChatWithProjectContext(project);
            setChatSession(session);
            setMessages([
                { sender: 'bot', text: `Hi there! I'm the virtual assistant for ${project.name}. How can I help you today?` }
            ]);
        }
    }, [isOpen, project]);
    
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    const handleSendMessage = useCallback(async () => {
        if (!userInput.trim() || !chatSession || isLoading) return;

        const userMessage: ChatMessage = { sender: 'user', text: userInput };
        setMessages(prev => [...prev, userMessage]);
        setUserInput('');
        setIsLoading(true);

        const botLoadingMessage: ChatMessage = { sender: 'bot', text: '', isLoading: true };
        setMessages(prev => [...prev, botLoadingMessage]);
        
        try {
            const stream = await sendMessageToBot(chatSession, userInput);
            let text = '';
            for await (const chunk of stream) {
                const chunkText = chunk.text;
                text += chunkText;
                setMessages(prev => prev.map((msg, index) => 
                    index === prev.length - 1 ? { ...msg, text: text, isLoading: true } : msg
                ));
            }
            setMessages(prev => prev.map((msg, index) => 
                index === prev.length - 1 ? { ...msg, isLoading: false } : msg
            ));

        } catch (error) {
            setMessages(prev => prev.slice(0, -1)); // Remove loading message
            setMessages(prev => [...prev, { sender: 'bot', text: 'Sorry, I am having trouble connecting. Please try again later.' }]);
        } finally {
            setIsLoading(false);
        }
    }, [userInput, chatSession, isLoading]);
    
    if (!process.env.API_KEY) {
        return null; // Don't render if API key is not available
    }

    return (
        <>
            <button
                onClick={() => setIsOpen(true)}
                className="fixed bottom-6 right-6 bg-indigo-600 text-white p-4 rounded-full shadow-lg hover:bg-indigo-700 transition-transform transform hover:scale-110 focus:outline-none z-50"
                aria-label="Open virtual assistant"
            >
                <MessageSquare size={24} />
            </button>

            {isOpen && (
                <div className="fixed bottom-0 right-0 sm:bottom-6 sm:right-6 w-full h-full sm:w-96 sm:h-[600px] bg-white dark:bg-gray-800 shadow-2xl rounded-t-lg sm:rounded-lg flex flex-col z-50">
                    {/* Header */}
                    <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
                        <h3 className="font-bold text-lg text-gray-900 dark:text-white">Virtual Assistant</h3>
                        <button onClick={() => setIsOpen(false)} className="p-2 text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white">
                            <X size={20} />
                        </button>
                    </div>

                    {/* Messages */}
                    <div className="flex-1 p-4 overflow-y-auto">
                        <div className="space-y-4">
                            {messages.map((msg, index) => (
                                <div key={index} className={`flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
                                    {msg.sender === 'bot' && <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-white flex-shrink-0"><Bot size={18}/></div>}
                                    <div className={`max-w-xs px-4 py-2 rounded-lg ${msg.sender === 'user' ? 'bg-indigo-500 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200'}`}>
                                        {msg.isLoading && msg.text === '' ? (
                                            <div className="flex items-center space-x-1">
                                                <span className="w-2 h-2 bg-current rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                                                <span className="w-2 h-2 bg-current rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                                                <span className="w-2 h-2 bg-current rounded-full animate-bounce"></span>
                                            </div>
                                        ) : msg.text}
                                    </div>
                                     {msg.sender === 'user' && <div className="w-8 h-8 rounded-full bg-gray-500 flex items-center justify-center text-white flex-shrink-0"><User size={18}/></div>}
                                </div>
                            ))}
                        </div>
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Input */}
                    <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                        <div className="flex items-center space-x-2">
                            <input
                                type="text"
                                value={userInput}
                                onChange={(e) => setUserInput(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                                placeholder="Ask a question..."
                                className="w-full px-4 py-2 bg-gray-100 dark:bg-gray-700 border border-transparent rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                disabled={isLoading}
                            />
                            <button onClick={handleSendMessage} disabled={isLoading || !userInput.trim()} className="bg-indigo-500 text-white p-3 rounded-md disabled:bg-indigo-300 disabled:cursor-not-allowed">
                                <Send size={20} />
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};

export default VirtualAssistant;
